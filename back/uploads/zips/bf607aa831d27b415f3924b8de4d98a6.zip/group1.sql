-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- ホスト: 127.0.0.1
-- 生成日時: 2026-06-03 20:26:48
-- サーバのバージョン： 10.4.32-MariaDB
-- PHP のバージョン: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- データベース: `group1`
--

-- --------------------------------------------------------

--
-- テーブルの構造 `menba`
--

CREATE TABLE `menba` (
  `no` int(10) UNSIGNED NOT NULL COMMENT 'NO',
  `name` varchar(20) NOT NULL COMMENT '画面表示用名',
  `del_flg` int(1) NOT NULL DEFAULT 0 COMMENT '削除フラグ(1: 削除、0: 有効)',
  `updated_by` varchar(20) NOT NULL DEFAULT 'hippo' COMMENT '最終更新者',
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp() COMMENT '最終更新日時',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() COMMENT '作成日時'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- テーブルのデータのダンプ `menba`
--

INSERT INTO `menba` (`no`, `name`, `del_flg`, `updated_by`, `updated_at`, `created_at`) VALUES
(1, '営業グループ', 0, 'hippo', '2022-04-11 03:37:59', '2022-04-11 03:37:59'),
(2, '総務グループ', 0, 'hippo', '2022-04-11 03:39:26', '2022-04-11 03:39:26'),
(3, '部長グループ', 0, 'hippo', '2022-04-11 03:39:52', '2022-04-11 03:39:52'),
(13, '新しいグループ１１', 0, 'hippo', '2024-06-18 11:59:39', '2024-06-18 11:56:22'),
(15, 'aaaa', 0, 'hippo', '2024-06-18 13:17:09', '2024-06-18 13:17:09');

-- --------------------------------------------------------

--
-- テーブルの構造 `menbachild`
--

CREATE TABLE `menbachild` (
  `no` int(10) UNSIGNED NOT NULL COMMENT 'NO',
  `menba_no` int(11) NOT NULL DEFAULT 0 COMMENT 'menba no',
  `user_no` int(11) NOT NULL DEFAULT 0 COMMENT 'user no',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() COMMENT '作成日時'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- テーブルのデータのダンプ `menbachild`
--

INSERT INTO `menbachild` (`no`, `menba_no`, `user_no`, `created_at`) VALUES
(7, 3, 9, '2022-04-26 08:39:13'),
(8, 3, 6, '2022-04-26 08:39:13'),
(64, 2, 9, '2022-05-12 16:51:42'),
(65, 2, 7, '2022-05-12 16:51:42'),
(66, 2, 8, '2022-05-12 16:51:42'),
(103, 13, 6, '2024-06-18 13:13:25'),
(104, 13, 8, '2024-06-18 13:13:25'),
(105, 13, 15, '2024-06-18 13:13:25'),
(108, 15, 4, '2024-06-18 13:35:44'),
(115, 1, 6, '2026-03-17 02:46:09'),
(116, 1, 4, '2026-03-17 02:46:09'),
(117, 1, 5, '2026-03-17 02:46:09');

-- --------------------------------------------------------

--
-- テーブルの構造 `t_file2`
--

CREATE TABLE `t_file2` (
  `no` int(10) UNSIGNED NOT NULL COMMENT '番号',
  `zipno` int(10) UNSIGNED DEFAULT 0 COMMENT 'zip番号',
  `fname` varchar(512) DEFAULT NULL COMMENT 'ファイル名（拡張子なし）',
  `smallname` varchar(256) DEFAULT NULL COMMENT '画像縮小ファイル名（拡張子なし）',
  `exten` varchar(256) DEFAULT NULL COMMENT '拡張子',
  `coments` text DEFAULT NULL COMMENT 'コメント',
  `echoflg` bigint(20) UNSIGNED DEFAULT 0 COMMENT '表示flg',
  `delflg` bigint(20) UNSIGNED DEFAULT 0 COMMENT '削除flg',
  `typeaa` varchar(256) DEFAULT NULL COMMENT 'タイプ',
  `sizeaa` bigint(20) UNSIGNED DEFAULT 0 COMMENT 'サイズ',
  `updete_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp() COMMENT 'ファイル更新日時',
  `userid` int(10) UNSIGNED DEFAULT 0 COMMENT '作成者id'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- テーブルのデータのダンプ `t_file2`
--

INSERT INTO `t_file2` (`no`, `zipno`, `fname`, `smallname`, `exten`, `coments`, `echoflg`, `delflg`, `typeaa`, `sizeaa`, `updete_at`, `userid`) VALUES
(1, 1, 'free4_077', 'cxpsksai', 'jpg', 'こめんと', 0, 0, 'image/jpeg', 42267, '2024-06-18 15:51:06', 4),
(2, 2, 'free4_077', 'rukb4chu', 'jpg', 'こめんと', 0, 0, 'image/jpeg', 42267, '2024-06-20 18:29:59', 4),
(3, 3, 'free4_077', 'ezqr3kcz', 'jpg', 'こめんと', 0, 0, 'image/jpeg', 42267, '2024-06-20 18:30:25', 4),
(4, 4, 'calenda', 'qkxnbs2y', 'png', 'こめんと', 0, 0, 'image/png', 13776, '2024-06-20 18:39:18', 4),
(5, 4, 'free4_077', 'qeyxvdas', 'jpg', 'こめんと', 0, 0, 'image/jpeg', 42267, '2024-06-20 18:39:18', 4),
(6, 6, 'free4_077', 'nytu3viq', 'jpg', 'こめんと', 0, 0, 'image/jpeg', 42267, '2024-06-30 20:44:13', 4),
(7, 7, 'free4_077', 'hdxi6tnw', 'jpg', 'こめんと', 0, 0, 'image/jpeg', 42267, '2024-06-30 20:44:46', 4),
(8, 8, 'free4_077', 'usarch4d', 'jpg', 'こめんと', 0, 0, 'image/jpeg', 42267, '2024-06-30 20:44:54', 4),
(9, 9, 'めだか', '', 'docx', 'こめんと', 0, 0, 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 12322, '2024-07-18 10:26:13', 4),
(10, 10, 'Linux Mint', '', 'pdf', 'こめんと', 0, 0, 'application/pdf', 2771438, '2024-08-07 13:11:05', 4),
(11, 11, 'Linux Mint', '', 'pdf', 'こめんと', 0, 0, 'application/pdf', 2771438, '2024-08-07 13:12:34', 4),
(12, 12, 'Linux Mint', '', 'pdf', 'こめんと', 0, 0, 'application/pdf', 2771438, '2024-08-07 13:15:34', 4),
(13, 13, 'Linux Mint', '', 'pdf', 'こめんと', 0, 0, 'application/pdf', 2771438, '2024-08-07 15:30:42', 4),
(14, 14, 'Linux Mint', '', 'pdf', 'こめんと', 0, 0, 'application/pdf', 2771438, '2024-08-07 15:38:32', 4),
(15, 15, 'Linux Mint', '', 'pdf', 'こめんと', 0, 0, 'application/pdf', 2771438, '2024-08-07 15:42:34', 4),
(16, 16, 'Linux Mint', '', 'pdf', 'こめんと', 0, 0, 'application/pdf', 2771438, '2024-08-07 17:26:36', 4),
(17, 17, 'Linux Mint', '', 'pdf', 'こめんと', 0, 0, 'application/pdf', 2771438, '2024-08-07 17:32:17', 4),
(18, 18, 'Linux Mint', '', 'pdf', 'こめんと', 0, 0, 'application/pdf', 2771438, '2024-08-07 17:33:18', 4),
(19, 19, 'Linux Mint', '', 'pdf', 'こめんと', 0, 0, 'application/pdf', 2771438, '2024-08-07 17:34:38', 4),
(20, 20, 'Linux Mint', '', 'pdf', 'こめんと', 0, 0, 'application/pdf', 2771438, '2024-08-11 23:13:46', 4);

-- --------------------------------------------------------

--
-- テーブルの構造 `t_login_history`
--

CREATE TABLE `t_login_history` (
  `user_id` int(11) NOT NULL,
  `login` datetime NOT NULL,
  `host_name` varchar(256) DEFAULT NULL,
  `user_agent` varchar(512) DEFAULT NULL,
  `status` int(11) NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp() COMMENT '最終更新日時'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- テーブルの構造 `t_zip2`
--

CREATE TABLE `t_zip2` (
  `no` int(10) UNSIGNED NOT NULL COMMENT '番号',
  `zipname` varchar(256) DEFAULT NULL COMMENT 'zipファイル名（拡張子なし）',
  `dlname` varchar(512) DEFAULT NULL COMMENT 'ダウンロードファイル名',
  `exten` varchar(256) DEFAULT NULL COMMENT '拡張子',
  `coments` text DEFAULT NULL COMMENT 'コメント',
  `echoflg` int(10) UNSIGNED DEFAULT 0 COMMENT '表示flg',
  `delflg` int(10) UNSIGNED DEFAULT 0 COMMENT '削除flg',
  `userid` int(10) UNSIGNED DEFAULT 0 COMMENT '作成者id',
  `updete_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp() COMMENT 'ファイル更新日時'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- テーブルのデータのダンプ `t_zip2`
--

INSERT INTO `t_zip2` (`no`, `zipname`, `dlname`, `exten`, `coments`, `echoflg`, `delflg`, `userid`, `updete_at`) VALUES
(1, 'xnmau3tj', 'free4_077', 'zip', 'コメント', 3, 0, 5, '2024-08-09 10:36:36'),
(2, 'tfvcfica', 'free4_077', 'zip', 'コメント', 9, 0, 8, '2024-06-30 21:33:20'),
(3, 'hsxcm6uz', 'free4_077', 'zip', 'コメント', 0, 0, 4, '2024-06-20 18:30:25'),
(4, 'nkdchign', 'calenda', 'zip', 'コメント', 9, 0, 7, '2024-08-11 06:34:11'),
(6, 'yurb0m6r', 'free4_077', 'zip', 'コメント', 3, 0, 8, '2024-08-09 10:36:36'),
(7, 'quzgxd9e', 'free4_077', 'zip', 'コメント', 0, 0, 4, '2024-06-30 20:44:46'),
(8, 'nvai4g5p', 'free4_077', 'zip', 'コメント', 3, 0, 6, '2024-08-09 10:36:36'),
(9, 'grsmuas5', 'めだか', 'zip', 'コメント１１', 9, 0, 8, '2024-08-09 11:11:33'),
(10, 'ixvztjps', 'Linux Mint', 'zip', 'コメント', 0, 0, 6, '2024-08-11 21:04:43'),
(11, 'udkepfra', 'Linux Mint', 'zip', 'コメント', 0, 0, 4, '2024-08-07 13:12:34'),
(12, 'nspcdvhb', 'Linux Mint', 'zip', 'コメント', 0, 0, 4, '2024-08-07 13:15:34'),
(13, 'mxdp8ich', 'Linux Mint', 'zip', 'コメント', 0, 1, 4, '2024-08-09 11:14:28'),
(14, 'whsu03fh', 'Linux Mint', 'zip', 'コメント', 0, 0, 4, '2024-08-07 15:38:32'),
(15, 'udekvqpe', 'Linux Mint', 'zip', 'コメント', 0, 0, 7, '2024-08-11 07:02:35'),
(16, 'xtkux2v6', 'Linux Mint', 'zip', 'コメント', 0, 0, 4, '2024-08-07 17:26:36'),
(17, 'xhpe7epj', 'Linux Mint', 'zip', 'コメント', 0, 0, 4, '2024-08-07 17:32:17'),
(18, 'uefvph21', 'Linux Mint', 'zip', 'コメント', 0, 0, 4, '2024-08-07 17:33:18'),
(19, 'nsxmgmh9', 'Linux Mint', 'zip', 'コメント', 9, 0, 4, '2024-08-08 10:19:21'),
(20, 'jdsfqn68', 'Linux Mint', 'zip', 'コメント', 0, 0, 4, '2024-08-11 23:13:46');

-- --------------------------------------------------------

--
-- テーブルの構造 `users`
--

CREATE TABLE `users` (
  `no` int(10) UNSIGNED NOT NULL COMMENT 'NO',
  `id` varchar(20) NOT NULL COMMENT 'ユーザーID',
  `pwd` varchar(60) NOT NULL COMMENT 'パスワード',
  `nickname` varchar(20) NOT NULL COMMENT '画面表示用名',
  `del_flg` int(1) NOT NULL DEFAULT 0 COMMENT '削除フラグ(1: 削除、0: 有効)',
  `updated_by` varchar(20) NOT NULL DEFAULT 'hippo' COMMENT '最終更新者',
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp() COMMENT '最終更新日時',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() COMMENT '作成日時',
  `ob` int(10) NOT NULL COMMENT '権利'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- テーブルのデータのダンプ `users`
--

INSERT INTO `users` (`no`, `id`, `pwd`, `nickname`, `del_flg`, `updated_by`, `updated_at`, `created_at`, `ob`) VALUES
(4, 'ei1', '$2y$10$vXR39BQyqr8.NR7SGOOB5eTy97IdSOBRowrWwlMIz//F4QsBp6syG', '営業１', 0, 'hippo', '2026-03-17 01:48:13', '2022-04-11 05:06:53', 0),
(5, 'ei2', '$2y$10$si6wS2L0jPVmJtp19uy0.unjEUtOG24q6BBCpyDgePULIZgPVHC5.', '営業2', 0, 'hippo', '2022-04-11 05:07:15', '2022-04-11 05:07:15', 0),
(6, 'ei9', '$2y$10$tbSfsFwbq2ucRilVoPE9d.G5Yl7dyxGut4Zc66m260ILPkMwke/h6', '営業部長', 0, 'hippo', '2022-04-11 05:07:46', '2022-04-11 05:07:46', 0),
(7, 'so1', '$2y$10$5lY6Im.6SkfLubgCl90OGuxqh8lapjzlKZU8z2dhE8RVv9LWtONPK', '総務１', 0, 'hippo', '2022-04-11 05:08:08', '2022-04-11 05:08:08', 0),
(8, 'so2', '$2y$10$4OHhfrggMZYSyS7ktZY9.On8oCVsIv9p9KthqOGeqOjI1dzvng3n6', '総務２', 0, 'hippo', '2022-04-11 05:08:27', '2022-04-11 05:08:27', 0),
(9, 'so9', '$2y$10$mP9dR73o7oexShp2TkwXeOdbsA6Pk/DpjZ7vZSoczDkSGtI.QRFDi', '総務部長', 0, 'hippo', '2022-04-11 05:09:02', '2022-04-11 05:09:02', 0),
(12, 'admin', '$2y$10$vXR39BQyqr8.NR7SGOOB5eTy97IdSOBRowrWwlMIz//F4QsBp6syG', '管理者', 0, 'hippo', '2026-03-17 01:45:59', '2022-05-16 19:53:35', 999),
(13, 'id', 'aaa', 'nickname', 0, 'hippo', '2024-06-18 13:05:07', '2024-06-18 13:05:07', 0),
(14, 'abc', '$2y$10$a7ynNUUGuteLpKcUOGmAReYotJdOLS9uhIHJjCszdvaxaw347se.m', 'aaa', 0, 'hippo', '2024-06-18 13:07:38', '2024-06-18 13:07:38', 0),
(15, 'bbb', '$2y$10$XDfyZvyQWwFrceJ5BD5CSO0EmlLmoKOei6dzTFL8rttLbY7Y4UreG', 'bbb', 0, 'hippo', '2024-06-18 13:10:02', '2024-06-18 13:10:02', 0),
(16, 'ccc', '$2y$10$FQd1A1/FzFebro0lI62vVusRhM.aVQjw7sfl4eunVWFYCSIxL0WRy', 'ccc', 0, 'hippo', '2024-06-18 13:12:15', '2024-06-18 13:12:15', 0),
(17, 'guest', '$2y$10$J5e51JcVwB9jkABAOPTNOupiKIE4Q.mhJ8sF9.Ote7xd6TEYMVkRi', 'guest', 0, 'hippo', '2024-08-08 09:29:00', '2024-08-08 09:28:28', 888);

--
-- ダンプしたテーブルのインデックス
--

--
-- テーブルのインデックス `menba`
--
ALTER TABLE `menba`
  ADD PRIMARY KEY (`no`);

--
-- テーブルのインデックス `menbachild`
--
ALTER TABLE `menbachild`
  ADD PRIMARY KEY (`no`);

--
-- テーブルのインデックス `t_file2`
--
ALTER TABLE `t_file2`
  ADD PRIMARY KEY (`no`);

--
-- テーブルのインデックス `t_login_history`
--
ALTER TABLE `t_login_history`
  ADD KEY `idx_login_history_user_id` (`user_id`,`login`);

--
-- テーブルのインデックス `t_zip2`
--
ALTER TABLE `t_zip2`
  ADD PRIMARY KEY (`no`);

--
-- テーブルのインデックス `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`no`),
  ADD UNIQUE KEY `id` (`id`);

--
-- ダンプしたテーブルの AUTO_INCREMENT
--

--
-- テーブルの AUTO_INCREMENT `menba`
--
ALTER TABLE `menba`
  MODIFY `no` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'NO', AUTO_INCREMENT=18;

--
-- テーブルの AUTO_INCREMENT `menbachild`
--
ALTER TABLE `menbachild`
  MODIFY `no` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'NO', AUTO_INCREMENT=118;

--
-- テーブルの AUTO_INCREMENT `t_file2`
--
ALTER TABLE `t_file2`
  MODIFY `no` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '番号', AUTO_INCREMENT=21;

--
-- テーブルの AUTO_INCREMENT `t_zip2`
--
ALTER TABLE `t_zip2`
  MODIFY `no` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '番号', AUTO_INCREMENT=21;

--
-- テーブルの AUTO_INCREMENT `users`
--
ALTER TABLE `users`
  MODIFY `no` int(10) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'NO', AUTO_INCREMENT=19;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
